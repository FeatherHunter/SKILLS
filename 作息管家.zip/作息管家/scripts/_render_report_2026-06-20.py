#!/usr/bin/env python3
"""
渲染 2026-06-20 作息报告 HTML
"""
import json
from pathlib import Path
from datetime import datetime
from collections import defaultdict

with open('/tmp/report_data_2026-06-20.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

records = data['records']
hours = data['hours']
cat_minutes = data['cat_minutes']
total_minutes = data['total_minutes']
total_hours = total_minutes / 60
sleep_records = data['sleep_records']
main_sleep = data['main_sleep']
meal_records = data['meal_records']
health_records = data['health_records']
work_records = data['work_records']
commute_records = data['commute_records']

# 颜色 & emoji
color_map = {
    "睡眠": "#5E5CE6", "工作": "#007AFF", "学习": "#34C759", "运动": "#FF9500",
    "通勤": "#64D2FF", "餐饮": "#FF9F0A", "娱乐": "#AF52DE", "社交": "#FF2D55",
    "休闲": "#30D158", "健康": "#FF3B30", "洗漱": "#5AC8FA", "兴趣爱好": "#BF8F5F",
    "居家": "#BF8F5F", "家政家务": "#A2845E", "居家管理": "#A2845E",
    "家务": "#A2845E", "生活": "#8E8E93", "未知": "#8E8E93", "休息": "#8E8E93",
    "其他": "#8E8E93", "烹饪": "#FF9F0A", "生活管理": "#A2845E",
}
emoji_map = {
    "睡眠": "😴", "工作": "💼", "学习": "📚", "运动": "🏋️",
    "通勤": "🚴", "餐饮": "🍽️", "娱乐": "🎮", "社交": "💕",
    "休闲": "🛋️", "健康": "🏥", "洗漱": "🚿", "兴趣爱好": "🎨",
    "居家": "🏠", "家政家务": "🧹", "居家管理": "🧹",
    "家务": "🧹", "生活": "🌱", "未知": "❓", "休息": "🛋️",
    "其他": "📌", "烹饪": "🍳", "生活管理": "📌",
}

# 排序分类（按时长倒序）
sorted_cats = sorted(cat_minutes.items(), key=lambda x: -x[1])

# ============ HTML 渲染 ============
def fmt_dur(mins):
    return f"{mins//60}小时{mins%60}分钟" if mins % 60 else f"{mins//60}小时"

def cat_emoji(c):
    return emoji_map.get(c, "📌")
def cat_color(c):
    return color_map.get(c, "#8E8E93")

# 渲染分类摘要
summary_html = []
for cat, mins in sorted_cats:
    emoji = cat_emoji(cat)
    color = cat_color(cat)
    pct = mins / total_minutes * 100
    summary_html.append(f'''    <div class="summary-item">
      <span class="emoji">{emoji}</span>
      <div class="info">
        <div class="cat">{cat}</div>
        <div class="dur">{fmt_dur(mins)}</div>
        <div class="bar"><div class="bar-fill" style="width:{pct:.1f}%;background:{color}"></div></div>
      </div>
    </div>''')
summary_html = '\n'.join(summary_html)

# 计算时间轴：使用每小时主导分类（按分钟数覆盖最多）
hour_cats = [None] * 24
hour_minutes = [defaultdict(int) for _ in range(24)]
for r in records:
    final_cat = r['category']
    try:
        h_start = int(r['time_start'].split(':')[0])
        s_min = int(r['time_start'].split(':')[1])
        if r['time_end'] == '23:59':
            e_min_total = 23 * 60 + 59
        elif r['time_end'] == '24:00':
            e_min_total = 24 * 60
        else:
            eh, em = map(int, r['time_end'].split(':'))
            e_min_total = eh * 60 + em
        s_min_total = h_start * 60 + s_min
        cur = s_min_total
        while cur < e_min_total:
            h = cur // 60
            if h < 24:
                next_hour = (h + 1) * 60
                covered = min(next_hour, e_min_total) - cur
                hour_minutes[h][final_cat] += covered
                cur = next_hour
            else:
                break
    except Exception as e:
        pass

# 取每小时主导分类
for h in range(24):
    if hour_minutes[h]:
        hour_cats[h] = max(hour_minutes[h].items(), key=lambda x: x[1])[0]
    else:
        hour_cats[h] = hours[h] or '休息'

# 渲染时间轴
timeline_html = []
for h in range(24):
    cat = hour_cats[h] or '休息'
    color = cat_color(cat)
    timeline_html.append(f'    <div class="timeline-block" style="background:{color}"><div class="tip">{h:02d}:00 {cat}</div></div>')
timeline_html = '\n'.join(timeline_html)

# 渲染时间轴图例（去重，基于新算法）
used_cats = []
for h in range(24):
    cat = hour_cats[h] or '休息'
    if cat not in used_cats:
        used_cats.append(cat)
legend_html = []
for cat in used_cats:
    color = cat_color(cat)
    legend_html.append(f'    <div class="legend-item"><div class="legend-dot" style="background:{color}"></div>{cat}</div>')
legend_html = '\n'.join(legend_html)

# 周几
weekday_map = {0: '周一', 1: '周二', 2: '周三', 3: '周四', 4: '周五', 5: '周六', 6: '周日'}
dt = datetime.strptime(data['date'], '%Y-%m-%d')
weekday = weekday_map[dt.weekday()]
date_cn = f"{dt.year}年{dt.month}月{dt.day}日"

# ============ 当日亮点 ============
highlights_html = '''    <div class="highlight-row">
      <span class="h-emoji">😴</span>
      <div>
        <div class="h-text">睡眠爆棚 9h1m：凌晨主睡眠 03:32~08:12 长达 4h40m，加上 00:00~03:32 3h32m 凌晨睡眠 + 14:18~14:19 1min 午睡 + 23:11~23:59 入睡 48min，4 段睡眠总计 9h1m（占全天 37.6%）。是周六的修复日，但凌晨 03:32 才进入主睡眠有点晚（应该是 00:00 还在睡眠中）</div>
        <div class="h-time">03:32~08:12 主睡眠 / 00:00~03:32 凌晨睡眠</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">🏥</span>
      <div>
        <div class="h-text">健康卡路里管理爆表 6h5m：10 段卡路里记录/咨询共 365min（占全天 25.4%，是第二高分类！）。从上午 10:38 体重+榴莲记录开始，到晚上 22:34 鸡蛋+今日摄入查询结束，几乎每吃一样东西都在查热量。这是过度纠结热量的信号，建议：① 设定每日摄入预算（1800~2200大卡）② 不用每样都查，对常见食物记住大致热量即可</div>
        <div class="h-time">10:38~11:14 / 12:02~13:24 / 14:54~15:56 / 17:58~19:36 / 19:55~20:51 / 22:34~23:11</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">🛋️</span>
      <div>
        <div class="h-text">休闲时间 3h55m：14:19~14:54 起床后过渡（35min）+ 15:56~17:16 心愿查询 1h20m + 17:33~17:41 心愿讨论 8min + 20:54~21:46 散步+看动漫解读 52min。散步+看凡人修仙传解读是健康休闲</div>
        <div class="h-time">15:56~17:16 心愿查询 / 20:54~21:46 散步</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">🎨</span>
      <div>
        <div class="h-text">居家管家深度使用 1h48m：8 段操作共 108min（占全天 7.5%）。上午集中录入新物品（蛋白粉 + 烤雪苹果片派 + 金枪鱼饼干），晚上 21:47~22:04 修炼元母意程 17min + 22:04~22:08 备忘录打卡 4min。居家管家已是日常管理工具，但卡路里查询可以独立成生活技能</div>
        <div class="h-time">08:12~10:38 上午集中录入</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">💼</span>
      <div>
        <div class="h-text">轻度工作 54min：13:24~14:18 方案b/PC端整理。这是周六，难得主动处理工作。建议：① 周日彻底休息，不碰工作 ② 每周保留 1 天纯休息日（参考周五 2026-06-19 0h 工作）</div>
        <div class="h-time">13:24~14:18 PC端整理</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">🍽️</span>
      <div>
        <div class="h-text">餐饮 34min：17:16~17:33 煮水饺做饭（17min）+ 17:41~17:58 准备吃包子（17min）。简单家常饭，没有大餐，符合周六节奏</div>
        <div class="h-time">17:16~17:33 水饺 / 17:41~17:58 包子</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">🎮</span>
      <div>
        <div class="h-text">娱乐 26min：11:14~11:40 看凡人修仙传 26min。娱乐时间较短，符合周六以休息为主的节奏</div>
        <div class="h-time">11:14~11:40 凡人修仙传</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">📌</span>
      <div>
        <div class="h-text">生活管理 + 烹饪 + 家务：生活管理 28min（居家管家物品位置描述 + 保存照片）、烹饪 24min（查询鸡蛋羹做法）、家务 9min（出门扔垃圾 3袋）。周末的生活事务处理很完整</div>
        <div class="h-time">22:10~22:34 鸡蛋羹 / 19:46~19:55 扔垃圾</div>
      </div>
    </div>'''

# ============ 睡眠分析 ============
sleep_total_min = cat_minutes.get('睡眠', 0)
sleep_h = sleep_total_min // 60
sleep_m = sleep_total_min % 60

sleep_html = f'''    <div class="highlight-row">
      <span class="h-emoji">&#x1F319;</span>
      <div>
        <div class="h-text">凌晨主睡眠 00:00~08:12 共 8h12m：从 00:00 持续到 08:12，中间无中断，是周六的长睡眠。其中 00:00~03:32 是前夜延续睡眠（3h32m），03:32~08:12 是后半夜睡眠（4h40m）。睡眠总时长 9h1m，超过 7-9h 推荐上限</div>
        <div class="h-time">00:00~08:12 持续 8h12m 无中断</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F634;</span>
      <div>
        <div class="h-text">午睡 1min（14:18~14:19）：仅 1min 的午睡信号，可能是「中午休息一下」的意思。属于"伪午睡"，并非真正睡眠。这说明用户没有午睡习惯，建议保持</div>
        <div class="h-time">14:18~14:19 仅 1min</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F4A4;</span>
      <div>
        <div class="h-text">23:11~23:59 入睡 48min：从 22:34 开始查鸡蛋+今日摄入，到 23:11 进入入睡准备，中间 37min 是清醒阶段。这与入睡拖延相关——查完卡路里就上床，脑子还在转。建议：睡前 1h 不做需要思考的活动（包括查卡路里）</div>
        <div class="h-time">⚠️ 22:34~23:11 清醒 37min 后才入睡</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F4CA;</span>
      <div>
        <div class="h-text">总睡眠 {sleep_h}h{sleep_m}m，超过 7-9h 推荐范围上限（9h）。但这是周六长睡眠，符合周末修复规律。明天周日如果休息，可以维持；如有安排，建议控制在 7-8h，避免过度睡眠带来惰性</div>
        <div class="h-time">总 {sleep_h}h{sleep_m}m（4 段）</div>
      </div>
    </div>'''

# ============ 改善建议 ============
suggest_html = '''    <div class="highlight-row">
      <span class="h-emoji">&#x1F489;</span>
      <div>
        <div class="h-text">卡路里管理过度纠结 ⚠️：今天 6h5m 用于卡路里记录/查询（占全天 25.4%），10 段操作分布在全天。这不是健康管理，是焦虑管理。建议：① 设定每日热量预算（如 1800~2200大卡）② 每天只查 1~2 次（早餐后 + 晚餐后）③ 对常见食物记大致热量（米饭≈200/碗，鸡腿≈150/个）④ 把卡路里作为参考，不是约束。健康的关键是均衡饮食 + 规律作息，不是精确计算</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F319;</span>
      <div>
        <div class="h-text">入睡拖延问题：昨晚 22:34~23:11 清醒 37min 才入睡（前晚 2026-06-19 也是同样模式）。建议：① 22:00 后关闭厨房/卡路里相关对话 ② 22:30 开始洗漱 + 冥想 5min ③ 23:00 前躺床闭眼。建立固定的「睡眠仪式」信号：洗漱=准备睡觉</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F3E0;</span>
      <div>
        <div class="h-text">居家管家操作粒度优化 ⚠️：今天 8 段居家管家操作（共 108min），部分操作过细（如蛋白粉看了 10min + 命名讨论 8min + 位置录入 13min 共 31min 才完成一个物品）。建议：① 一个物品一次性完成查看+命名+位置录入，避免来回切换 ② 批量操作（如一次处理 3~5 个物品）③ 这能减少 50% 的切换成本</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F4F1;</span>
      <div>
        <div class="h-text">心愿系统使用记录：15:56~17:16 心愿查询 1h20m + 17:33~17:41 心愿讨论 8min，共 1h28m。心愿是一个值得投入的功能，但查询时间过长说明数据组织可能不够直观。建议：① 按心愿状态分组（待办/进行中/已完成）② 优先级标注（高/中/低）③ 结合时间维度（今日/本周/长期）</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F4DA;</span>
      <div>
        <div class="h-text">周六工作取舍：今天 13:24~14:18 工作 54min（方案b/PC端整理）。周六适度处理工作可以接受，但建议：① 设定时间上限（如不超过 1h）② 与休息明确分开（不在休息/睡眠前后工作）③ 周末保留至少 1 天纯休息（参考 2026-06-19 周五 0h 工作）</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F6B6;</span>
      <div>
        <div class="h-text">散步 + 凡人修仙传解读是好组合：20:54~21:46 散步 52min 看动漫解读。这种"轻度运动 + 娱乐内容"组合很健康，建议保留并扩展（如加入播客/有声书）。如果未来想升级，可以尝试快走 30min + 正常速度 20min</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x1F33E;</span>
      <div>
        <div class="h-text">修炼 + 备忘录打卡：21:47~22:04 修炼元母意程 17min + 22:04~22:08 备忘录打卡 4min。坚持修炼和打卡是好习惯，21:47~22:08 共 21min 是稳定的时间块。建议保持这个时段作为「内观+记录」专属时间</div>
      </div>
    </div>
    <div class="highlight-row">
      <span class="h-emoji">&#x2705;</span>
      <div>
        <div class="h-text">保留的好习惯：① 长睡眠 9h1m 充分修复 ② 健康卡路里管理意识（虽然过度）③ 居家管家数据持续完善 ④ 散步+娱乐的健康组合 ⑤ 心愿系统思考 ⑥ 修炼打卡持续 ⑦ 简单家常饭 ⑧ 出门扔垃圾 3 袋的家务习惯 ⑨ 凡人修仙传作为放松内容</div>
      </div>
    </div>'''

# ============ 完整 HTML ============
html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>作息报告 - {date_cn}（{weekday}）</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Pro Display","PingFang SC","Microsoft YaHei",sans-serif;background:#f5f5f7;color:#1d1d1f;line-height:1.6;-webkit-font-smoothing:antialiased}}
.container{{max-width:720px;margin:0 auto;padding:24px 16px}}
.header{{text-align:center;padding:32px 0 24px}}
.header h1{{font-size:28px;font-weight:700;letter-spacing:-.5px}}
.header .date{{font-size:15px;color:#86868b;margin-top:4px}}
.header .weekday{{display:inline-block;font-size:12px;font-weight:500;color:#fff;background:#007AFF;border-radius:12px;padding:2px 10px;margin-top:8px}}
.card{{background:#fff;border-radius:14px;padding:24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,.04)}}
.card h2{{font-size:17px;font-weight:600;margin-bottom:16px;display:flex;align-items:center;gap:8px}}
.card h2 .icon{{font-size:20px}}
.summary-grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}}
.summary-item{{display:flex;align-items:center;padding:12px 14px;background:#f5f5f7;border-radius:10px;gap:10px}}
.summary-item .emoji{{font-size:22px;width:32px;text-align:center;flex-shrink:0}}
.summary-item .info{{flex:1;min-width:0}}
.summary-item .cat{{font-size:13px;font-weight:500;color:#1d1d1f}}
.summary-item .dur{{font-size:12px;color:#86868b;margin-top:1px}}
.summary-item .bar{{height:4px;background:#e5e5e5;border-radius:2px;margin-top:6px;overflow:hidden}}
.summary-item .bar-fill{{height:100%;border-radius:2px;transition:width .6s ease}}
.total-row{{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;background:#f5f5f7;border-radius:10px;margin-top:12px}}
.total-row .label{{font-size:14px;font-weight:500;color:#1d1d1f}}
.total-row .value{{font-size:20px;font-weight:700;color:#007AFF}}
.total-row .check{{font-size:14px;color:#34c759;margin-left:6px}}
.timeline{{display:flex;gap:2px;height:40px;border-radius:8px;overflow:hidden;margin-bottom:8px}}
.timeline-block{{flex:1;position:relative;cursor:pointer;transition:opacity .15s}}
.timeline-block:hover{{opacity:.8}}
.timeline-block .tip{{display:none;position:absolute;bottom:calc(100% + 6px);left:50%;transform:translateX(-50%);background:#1d1d1f;color:#fff;font-size:11px;padding:4px 8px;border-radius:6px;white-space:nowrap;z-index:10;pointer-events:none}}
.timeline-block:hover .tip{{display:block}}
.timeline-labels{{display:flex;justify-content:space-between;font-size:10px;color:#86868b;padding:0 2px}}
.legend{{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}}
.legend-item{{display:flex;align-items:center;gap:4px;font-size:11px;color:#86868b}}
.legend-dot{{width:10px;height:10px;border-radius:3px;flex-shrink:0}}
.highlights{{display:flex;flex-direction:column;gap:10px}}
.highlight-row{{display:flex;align-items:flex-start;gap:10px;padding:10px 14px;background:#f5f5f7;border-radius:10px}}
.highlight-row .h-emoji{{font-size:18px;flex-shrink:0;margin-top:1px}}
.highlight-row .h-text{{font-size:13px;color:#1d1d1f;line-height:1.5}}
.highlight-row .h-time{{font-size:12px;color:#86868b;margin-top:2px}}
.footer{{text-align:center;padding:20px 0;font-size:11px;color:#86868b}}
@media(max-width:480px){{.summary-grid{{grid-template-columns:1fr}}.container{{padding:16px 12px}}}}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <h1>每日作息报告</h1>
  <div class="date">{date_cn}</div>
  <span class="weekday">{weekday}</span>
</div>

<div class="card">
  <h2><span class="icon">&#x1F4CA;</span> 时间分配</h2>
  <div class="summary-grid">
{summary_html}
  </div>
  <div class="total-row">
    <span class="label">总计</span>
    <span><span class="value">{fmt_dur(total_minutes)}</span><span class="check">&#x2713;</span></span>
  </div>
</div>

<div class="card">
  <h2><span class="icon">&#x1F550;</span> 24小时时间轴</h2>
  <div class="timeline">
{timeline_html}
  </div>
  <div class="timeline-labels">
    <span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>23:59</span>
  </div>
  <div class="legend">
{legend_html}
  </div>
</div>

<div class="card">
  <h2><span class="icon">&#x2B50;</span> 当日亮点</h2>
  <div class="highlights">
{highlights_html}
  </div>
</div>

<div class="card">
  <h2><span class="icon">&#x1F634;</span> 睡眠分析</h2>
  <div class="highlights">
{sleep_html}
  </div>
</div>

<div class="card">
  <h2><span class="icon">&#x1F4A1;</span> 改善建议</h2>
  <div class="highlights">
{suggest_html}
  </div>
</div>

<div class="footer">
  作息管家 · 自动生成于 {datetime.now().strftime("%Y-%m-%d %H:%M")} · 共 {data['total_records']} 个记录块
</div>

</div>
</body>
</html>'''

REPORT_PATH = Path('/mnt/d/2Study/StudyNotes/SKILLS/作息管家/reports/2026-06-20.html')
REPORT_PATH.write_text(html, encoding='utf-8')
print(f"✓ HTML 报告已生成: {REPORT_PATH}")
print(f"  文件大小: {REPORT_PATH.stat().st_size} bytes")